#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#include <shellapi.h>	// if using WIN32_LEAN_AND_MEAN then explicitly include shellapi.h for CommandLineToArgvW()
#include <wincodecsdk.h>
#include <stdio.h>	// C string functions that end with *_s are safe version of standard routines, eg: wcscpy_s, swscanf_s


HRESULT RecodeFile(LPCWSTR pszSourceFile, LPCWSTR pszDestinationFile, FLOAT fQuality, UINT nSubsampling, UINT dstWidth = 0, UINT dstHeight = 0);

// Great articles and samples:
// The fastest way to resize images from ASP.NET: http://weblogs.asp.net/bleroy/the-fastest-way-to-resize-images-from-asp-net-and-it-s-more-supported-ish
// Chapter 11: Using the Windows Imaging Component: https://msdn.microsoft.com/en-us/library/windows/desktop/ff973956.aspx

// How-to: Re-encode a JPEG Image with Metadata http://msdn.microsoft.com/en-us/library/ee719794(VS.85).aspx
// also WIC Tools: http://archive.msdn.microsoft.com/wictools/Release/ProjectReleases.aspx?ReleaseId=2887
int WINAPI wWinMain(__in HINSTANCE hInstance, __in_opt HINSTANCE hPrevInstance, __in LPWSTR lpCmdLine, __in int nShowCmd)
{
	int	nArgs = 0;
	LPWSTR	*pArgs = NULL;

	pArgs = ::CommandLineToArgvW(lpCmdLine, &nArgs);

	LPCWSTR pszErrorMessage = NULL;
	LPCWSTR	pszSourceFile = NULL;			// the only mandatory parameter
	LPCWSTR pszDestinationFile = NULL;		// optional destination file
	WCHAR	szTempFile[MAX_PATH] = { 0 };	// if destination is not specified, creating a temporary file
	FLOAT	fQuality = 0.85f;				// /Q:<x>, quality n = 0.0 to 1.0, default is 0.85 (85%)
	UINT	unSubsampling = 1;				// /C:<n>, YCrCb chroma subsampling, where x stands 1 for 4:2:0, 2 - 4:2:2, 3 - 4:4:4, 4 - 4:4:0, 0 - system default
	UINT	unWidth = 0;					// /W:<n>
	UINT	unHeight = 0;					// /H:<n>

	// iterate through parameters and parse them accordingly
	for (int i = 0; i < nArgs; i++)
	{
		LPCWSTR arg = pArgs[i];
		int nRet = 0;

		if (*arg == '/')	// if an argument starts with '/'
		{
			switch (*(arg + 1))
			{
			case 'q':
			case 'Q':
				nRet = swscanf_s(arg + 2, L":%f", &fQuality);
				if (nRet != 1)
					pszErrorMessage = L"/Q parameter is incorrect.\n Example of usage: /Q:0.85";
				break;
			case 'c':
			case 'C':
				nRet = swscanf_s(arg + 2, L":%u", &unSubsampling);
				if (nRet != 1)
					pszErrorMessage = L"/C parameter is incorrect.\n Example of usage: /C:1";
				break;
			case 'w':
			case 'W':
				nRet = swscanf_s(arg + 2, L":%u", &unWidth);
				if (nRet != 1)
					pszErrorMessage = L"/W parameter is incorrect.\n Example of usage: /W:300";
				break;
			case 'h':
			case 'H':
				nRet = swscanf_s(arg + 2, L":%u", &unHeight);
				if (nRet != 1)
					pszErrorMessage = L"/H parameter is incorrect.\n Example of usage: /H:300";
				break;
			default:
				pszErrorMessage = L"Not supported parameter.\n The only parameters supported are /Q /C /W /H, for example: /Q:0.85 /C:1 /W:300 /H:300";
				break;
			}
		}
		else
		{
			if (!pszSourceFile)
				pszSourceFile = arg;
			else if (!pszDestinationFile)
				pszDestinationFile = arg;
			else
				pszErrorMessage = L"Not supported parameter.\n Usage:\nApticon.ImgMinify.exe \"d:\\path\\source.jpg\" \"d:\\path\\target.jpg\" /Q:0.85 /C:1 /W:300 /H:200\n"
				L"\t/C:<n>, YCrCb chroma subsampling, where x stands 1 for 4:2:0, 2 - 4:2:2, 3 - 4:4:4, 4 - 4:4:0, 0 - system default; if not specified the defaul is 1\n"
				L"\t/Q:<x>, quality x = 0.0 to 1.0; if not specified the default is 0.85 (85%)"
				L"\t/W:<w> and /H:<h> - where w and h are width and height in pixels; if not specified the original image dimensions are used";
		}
	}

	// not specified destination filename then use a temporary filename
	if (!pszErrorMessage && pszSourceFile && !pszDestinationFile)
	{
		wcscpy_s(szTempFile, MAX_PATH, pszSourceFile);
		wcscat_s(szTempFile, MAX_PATH, L".temp");
		pszDestinationFile = szTempFile;
	}

	// recode the file if there were no errors
	if (!pszErrorMessage && pszSourceFile && pszDestinationFile)
	{
		HRESULT hr = RecodeFile(pszSourceFile, pszDestinationFile, fQuality, unSubsampling, unWidth, unHeight);
		if (SUCCEEDED(hr))
		{
			// rename the destination into source if temp file was used
			if (*szTempFile)
			{
				BOOL bRet = ::MoveFileEx(pszDestinationFile, pszSourceFile, MOVEFILE_REPLACE_EXISTING);
				if (!bRet)
				{
					DWORD	dwErr = ::GetLastError();
					pszErrorMessage = L"Error renaming recompressed file into original";
				}
			}
		}
		else
		{
			pszErrorMessage = L"RecodeFile() COM Error";
			// TODO: convert HRESULT to a string error thru FormatMessage() http://support.microsoft.com/en-us/kb/256348/en-us
		}
	}

	// if there were errors display error message
	if (pszErrorMessage)
	{
		// TODO: check to see if produce console or Windows output - MessageBox vs Console output
		::MessageBox(NULL, pszErrorMessage, L"Apticon.ImgMinify", MB_ICONERROR | MB_OK);
	}
	else if (!pszSourceFile)	// no arguments passed or the only mandatory parameter is missing
	{
		::MessageBox(NULL, L"Usage:\nApticon.ImgMinify.exe \"d:\\path\\source.jpg\" [\"d:\\path\\target.jpg\"] [/Q:0.85] [/C:1] [/W:300] [/H:200]", L"Apticon.ImgMinify", MB_ICONINFORMATION | MB_OK);
	}

	// clean up of argument parsing memory allocation
	if (pArgs)
	{
		::LocalFree(pArgs);
		pArgs = NULL;
	}

	return -1;
}

// JPEG YCbCr Support http://msdn.microsoft.com/en-us/library/windows/desktop/dn424131.aspx
// Chroma Subsampling: 4:4:4 - 24 bits per pixel; 4:2:2, 4:4:0 - 16 bits per pixel; 4:2:0 - 12 bits per pixel;
// Large-to-smaller size subsampling: WICJpegYCrCbSubsampling444 -> [WICJpegYCrCbSubsampling440] -> WICJpegYCrCbSubsampling422 -> WICJpegYCrCbSubsampling420
HRESULT RecodeFile(LPCWSTR pszSourceFile, LPCWSTR pszDestinationFile, FLOAT fQuality, UINT unSubsampling, UINT dstWidth, UINT dstHeight)
{
    HRESULT hr = ::CoInitializeEx(NULL, COINIT_MULTITHREADED | COINIT_DISABLE_OLE1DDE);

	// WIC Imaging Factory
    IWICImagingFactory *piFactory = NULL;

    // Create the COM imaging factory.
    if (SUCCEEDED(hr))
        hr = ::CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&piFactory));

	// Decoder
	IWICBitmapDecoder *piDecoder = NULL;

	// Create the decoder. WICDecodeMetadataCacheOnDemand - for JPEG lossless decoding/encoding.
    if (SUCCEEDED(hr))
        hr = piFactory->CreateDecoderFromFilename(pszSourceFile, NULL, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &piDecoder);

    // Variables used for encoding.
    IWICStream *piEncoderFileStream = NULL;
    IWICBitmapEncoder *piEncoder = NULL;

    WICPixelFormatGUID pixelFormat = { 0 };
    UINT count = 0;
    double dpiX, dpiY = 0.0;
	UINT srcWidth, srcHeight = 0;
    UINT width, height = 0;
	bool bScaleImage = false;

    // Create a file stream.
    if (SUCCEEDED(hr))
		hr = piFactory->CreateStream(&piEncoderFileStream);

    // Initialize our new file stream.
    if (SUCCEEDED(hr))
		hr = piEncoderFileStream->InitializeFromFilename(pszDestinationFile, GENERIC_WRITE);

    // Create the encoder.
    if (SUCCEEDED(hr))
        hr = piFactory->CreateEncoder(GUID_ContainerFormatJpeg, NULL, &piEncoder);

	// Initialize the encoder
    if (SUCCEEDED(hr))
		hr = piEncoder->Initialize(piEncoderFileStream, WICBitmapEncoderNoCache);

    if (SUCCEEDED(hr))
        hr = piDecoder->GetFrameCount(&count);

    if (SUCCEEDED(hr))
    {
        // Process each frame of the image.
        for (UINT i = 0; i < count && SUCCEEDED(hr); i++)
        {
            // Frame variables.
            IWICBitmapFrameDecode *piFrameDecode = NULL;
            IWICBitmapFrameEncode *piFrameEncode = NULL;
			IPropertyBag2 *piPropertybag = NULL;

            // Get and create the image frame.
            if (SUCCEEDED(hr))
                hr = piDecoder->GetFrame(i, &piFrameDecode);

			if (SUCCEEDED(hr))
                hr = piEncoder->CreateNewFrame(&piFrameEncode, &piPropertybag);	// getting the property bag for customizing the encoder
			
			// customizing JPEG output
			// Encoding Overview http://msdn.microsoft.com/en-us/library/windows/desktop/ee719871.aspx
			// JPEG Format Overview http://msdn.microsoft.com/en-us/library/windows/desktop/gg430026.aspx
			if (SUCCEEDED(hr))
			{
				// encoder parameters: https://msdn.microsoft.com/en-us/library/windows/desktop/ee719871#encoderoptions
				// Property Name		VARTYPE		Value
				// ImageQuality			VT_R4		0-1.0
				// BitmapTransform		VT_UI1		WICBitmapTransformOptions
				// JpegYCrCbSubsampling	VT_UI1		WICJpegYCrCbSubsamplingOption

				// code sample on using the property bag: https://msdn.microsoft.com/en-us/library/windows/desktop/ee719871#encoder_options_examples
				PROPBAG2 option1 = { 0 };
				option1.pstrName = L"ImageQuality";
				VARIANT varValue1;
				VariantInit(&varValue1);
				varValue1.vt = VT_R4;
				varValue1.fltVal = fQuality;
				hr = piPropertybag->Write(1, &option1, &varValue1);

				
				PROPBAG2 option2 = { 0 };
				option2.pstrName = L"JpegYCrCbSubsampling";
				VARIANT varValue2;
				VariantInit(&varValue2);
				varValue2.vt = VT_UI1;
				varValue2.bVal = (WICJpegYCrCbSubsamplingOption)unSubsampling;
				hr = piPropertybag->Write(1, &option2, &varValue2);
			}

            // Initialize the encoder.
            if (SUCCEEDED(hr))
                hr = piFrameEncode->Initialize(piPropertybag);

            // get the source size
            if (SUCCEEDED(hr))
                hr = piFrameDecode->GetSize(&srcWidth, &srcHeight);

			// set the target size
			if (SUCCEEDED(hr))
            {
				if (dstWidth != 0 && dstHeight != 0)
				{
					// explicitly specified new size
					width = dstWidth;
					height = dstHeight;
				}
				else if (dstWidth == 0 && dstHeight != 0)
				{
					// dstHeight only specified, then use it for scaling
					width = (UINT)(((double)dstHeight / srcHeight) * srcWidth);
					height = dstHeight;
				}
				else if (dstHeight == 0 && dstWidth != 0)
				{
					// dstWidth only specified, then use it for scaling
					height = (UINT)(((double)dstWidth / srcWidth) * srcHeight);
					width = dstWidth;
				}
				else
				{
					width = srcWidth;
					height = srcHeight;
				}

				bScaleImage = (width != srcWidth || height != srcHeight);

				hr = piFrameEncode->SetSize(width, height);
			}

            // Get and set the resolution.
            if (SUCCEEDED(hr))
                piFrameDecode->GetResolution(&dpiX, &dpiY);

			if (SUCCEEDED(hr))
                hr = piFrameEncode->SetResolution(dpiX, dpiY);

            // Set the pixel format.
            if (SUCCEEDED(hr))
                piFrameDecode->GetPixelFormat(&pixelFormat);

			if (SUCCEEDED(hr))
                hr = piFrameEncode->SetPixelFormat(&pixelFormat);

            // Check that the destination format and source formats are the same.
            bool formatsEqual = FALSE;
            if (SUCCEEDED(hr))
            {
                GUID srcFormat;
                GUID dstFormat;

                hr = piDecoder->GetContainerFormat(&srcFormat);
				if (SUCCEEDED(hr))
                    hr = piEncoder->GetContainerFormat(&dstFormat);

				if (SUCCEEDED(hr))
                {
                    if (srcFormat == dstFormat)
                        formatsEqual = true;
                    else
                        formatsEqual = false;
                }
            }

			// Copy metadata using metadata block reader/writer.
			if (SUCCEEDED(hr) && formatsEqual)
            {
				IWICMetadataBlockWriter *piBlockWriter = NULL;
				IWICMetadataBlockReader *piBlockReader = NULL;

				if (SUCCEEDED(hr))
                    hr = piFrameDecode->QueryInterface(IID_PPV_ARGS(&piBlockReader));

				if (SUCCEEDED(hr))
                    hr = piFrameEncode->QueryInterface(IID_PPV_ARGS(&piBlockWriter));

				if (SUCCEEDED(hr))
                    hr = piBlockWriter->InitializeFromBlockReader(piBlockReader);

				// write additional metadata if required?
				//IWICMetadataQueryReader *piFrameQReader = NULL;
				//IWICMetadataQueryWriter *piFrameQWriter = NULL;
				//
				//if (SUCCEEDED(hr))
				//	hr = piFrameEncode->GetMetadataQueryWriter(&piFrameQWriter);
				//
				//if (SUCCEEDED(hr))
				//{
				//	// Add additional metadata.
				//	//PROPVARIANT    value;
				//	//value.vt = VT_LPWSTR;
				//	//value.pwszVal= L"Apticon.ImgMinify Recompressed Image";
				//	//hr = piFrameQWriter->SetMetadataByName(L"/xmp/dc:title", &value);
				//}
				//if (piFrameQWriter)
				//	piFrameQWriter->Release();
				//if (piFrameQReader)
				//	piFrameQReader->Release();

				if (piBlockWriter)
					piBlockWriter->Release();

				if (piBlockReader)
					piBlockReader->Release();
			}

			// Encode each frame
            if (SUCCEEDED(hr))
            {
				if (!bScaleImage)	// NO SCALING
				{
					hr = piFrameEncode->WriteSource(static_cast<IWICBitmapSource*> (piFrameDecode), NULL); // Using NULL enables JPEG loss-less encoding
				}
				else				// SCALING
				{
					IWICBitmapScaler	*piScaler = NULL;

					hr = piFactory->CreateBitmapScaler(&piScaler);

					if (SUCCEEDED(hr))
						hr = piScaler->Initialize(static_cast<IWICBitmapSource*> (piFrameDecode), width, height, WICBitmapInterpolationModeFant);

					if (SUCCEEDED(hr))
						hr = piFrameEncode->WriteSource(static_cast<IWICBitmapSource*>(piScaler), NULL);

					if (piScaler)
						piScaler->Release();
				}
			}

            // Commit the frame.
            if (SUCCEEDED(hr))
                hr = piFrameEncode->Commit();

			// release all interfaces
			if (piPropertybag)
				piPropertybag->Release();

			if (piFrameEncode)
				piFrameEncode->Release();

			if (piFrameDecode)
				piFrameDecode->Release();
        }
    }

    if (SUCCEEDED(hr))
        hr = piEncoder->Commit();

    if (SUCCEEDED(hr))
		piEncoderFileStream->Commit(STGC_DEFAULT);	// ignore as it returns E_NOTIMPL

	// releasing all interfaces
	if (piEncoder)
		piEncoder->Release();
	if (piEncoderFileStream)
		piEncoderFileStream->Release();
	if (piDecoder)
		piDecoder->Release();
	if (piFactory)
		piFactory->Release();

	::CoUninitialize();

	return hr;
}